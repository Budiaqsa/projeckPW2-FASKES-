/*=========================================================================================
    File Name: const-plyr.js
    Description: Media Player
    --------------------------------------------------------------------------------------
    Item Name: Vuesax HTML Admin Template
    Version: 1.1
    Author: PIXINVENT
    Author URL: http://www.themeforest.net/user/pixinvent
==========================================================================================*/

// Media Player
var player = new Plyr('#player');
