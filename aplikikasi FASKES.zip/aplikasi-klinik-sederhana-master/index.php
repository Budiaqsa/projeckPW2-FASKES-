<?php 

require_once 'app/templates/layout.php';
