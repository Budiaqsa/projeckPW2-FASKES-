<?php 

switch (isset($_GET['page'])) {
  case 'register':
    # code...
    break;
  
  default:
    # code...
    break;
}
