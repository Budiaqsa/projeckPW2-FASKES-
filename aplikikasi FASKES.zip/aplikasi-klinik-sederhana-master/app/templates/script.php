<!-- BEGIN: Theme JS-->
<script src="assets/js/core/app-menu.js"></script>
<script src="assets/js/core/app.js"></script>
<script src="assets/js/scripts/components.js"></script>
<!-- END: Theme JS-->

<!-- BEGIN: Page Vendor JS-->
<script src="assets/vendors/js/tables/datatable/pdfmake.min.js"></script>
<script src="assets/vendors/js/tables/datatable/vfs_fonts.js"></script>
<script src="assets/vendors/js/tables/datatable/datatables.min.js"></script>
<script src="assets/vendors/js/tables/datatable/datatables.buttons.min.js"></script>
<script src="assets/vendors/js/tables/datatable/buttons.html5.min.js"></script>
<script src="assets/vendors/js/tables/datatable/buttons.print.min.js"></script>
<script src="assets/vendors/js/tables/datatable/buttons.bootstrap.min.js"></script>
<script src="assets/vendors/js/tables/datatable/datatables.bootstrap4.min.js"></script>
<script src="assets/vendors/js/extensions/sweetalert2.all.min.js"></script>
<!-- END: Page Vendor JS-->

<script src="assets/js/scripts/datatables/datatable.js"></script>

<!-- BEGIN: Page JS-->
<script src="assets/js/scripts/pages/dashboard-analytics.js"></script>
<script src="assets/js/scripts/extensions/sweet-alerts.js"></script>
<!-- END: Page JS-->